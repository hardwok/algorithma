/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package linkedlist;
import java.util.*;
/**
 *
 * @author STAFF 8704
 */

public class SinglyLinkedList {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    List<String> list = new LinkedList<>();

     //Adding elements to the Linked list
      list.add("1");
      list.add("2");
      list.add("3");
      list.add("4");
      list.add("5");
      //list.addLast("Z");
      //list.addFirst("A");
      list.add(1, "6");
      System.out.println("Original contents of list: " + list);

      // remove elements from the linked list
      list.remove("3");
      list.remove(2);
      System.out.println("Contents of list after deletion: " + list);
      
      // remove first and last elements
      //list.removeFirst();
      //list.removeLast();
      System.out.println("list after deleting first and last: " + list);

      // get and set a value
      Object val = list.get(2);
      list.set(2, (String) val + " Changed");
      System.out.println("list after change: " + list);
   } 
}
